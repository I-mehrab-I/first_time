@extends("layout.main")

@section('body')

<x-card-component></x-card-component>
@endsection
cvlvl blblblblblblblblblbl 