<div>
    <section  class="pt-20 lg:pt-[120px] pb-10 lg:pb-20 bg-[#F3F4F6]">
        <div  class="container">
           <div  class="flex flex-wrap -mx-4">
              <div  class="w-full md:w-1/2 xl:w-1/3 px-4">
                 <div style="background-color: red;" class="bg-white rounded-lg overflow-hidden mb-10">
                    <img
                       src="https://cdn.tailgrids.com/1.0/assets/images/cards/card-01/image-01.jpg"
                       alt="image"
                       class="w-full"
                       />
                    <div class="p-8 sm:p-9 md:p-7 xl:p-9 text-center">
                       <h3>
                          <a
                          style="color: black"
                             href="javascript:void(0)"
                             class="
                             font-semibold
                             text-dark text-xl
                             sm:text-[22px]
                             md:text-xl
                             lg:text-[22px]
                             xl:text-xl
                             2xl:text-[22px]
                             mb-4
                             block
                             hover:text-primary
                             "
                             >
                          50+ Best creative website themes & templates
                          </a>
                       </h3>
                       <br>
                       <button class="button-62" role="button">submit</button>
                    </div>
                 </div>
              </div>
                    </div>
                 </div>
              </div>
              
           </div>
        </div>
     </section>
</div><?php /**PATH /home/teacher/Music/poulstar_work/my-blog/resources/views/components/card-component.blade.php ENDPATH**/ ?>