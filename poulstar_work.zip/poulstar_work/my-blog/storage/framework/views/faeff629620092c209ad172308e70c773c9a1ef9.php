<?php $__env->startSection('body'); ?>

<?php if (isset($component)) { $__componentOriginal3c35ee6afd3809180db3a3b1cd29a407711110fc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardComponent::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\CardComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c35ee6afd3809180db3a3b1cd29a407711110fc)): ?>
<?php $component = $__componentOriginal3c35ee6afd3809180db3a3b1cd29a407711110fc; ?>
<?php unset($__componentOriginal3c35ee6afd3809180db3a3b1cd29a407711110fc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/teacher/Music/poulstar_work/my-blog/resources/views/pages/index.blade.php ENDPATH**/ ?>