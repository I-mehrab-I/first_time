<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://unpkg.com/tailwindcss@0.3.0/dist/tailwind.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>

    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('body'); ?>

    <?php echo $__env->yieldContent('script'); ?>

    <?php echo $__env->yieldContent('footer'); ?>
    
</body>
</html><?php /**PATH /home/teacher/Music/poulstar_work/my-blog/resources/views/layout/main.blade.php ENDPATH**/ ?>