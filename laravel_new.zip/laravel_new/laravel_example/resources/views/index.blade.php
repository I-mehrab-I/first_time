<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        #sd{
            margin-left: 44%;
            color: red;
            text-shadow: 1px 1px 3px black;
        
        }

        #ds{
            margin-left: 43%;
            color: rgba(255, 0, 0, 0.644);
            text-shadow: 1px 1px 1px black;
        }
        .fg{
            background-color: black;
        }
    </style>
</head>
<body class="fg">

    <h1 id="sd"> hello world </h1>

    <h4 id="ds">
        welcom to my example website
    </h4>

    {{-- <img src="" alt=""> --}}

    <
    


    
    
</body>
</html>